import boto3
from datetime import datetime
import pytz
from mysql import imgUrl_update

list ={'성재윤':1, '이채영':2}

ACCESS_KEY_ID = 'AKIA5VZTIAOJ3SESRZ2R' #s3 관련 권한을 가진 IAM계정 정보
ACCESS_SECRET_KEY = 'MfIhjCIY6IdOaw683Ep6N6U67al3FMef4QP6GxqJ'
BUCKET_NAME = 'team7-dmdm'

def handle_upload_img(name): # f = 파일명
	today = str(datetime.now()).split(' ')[0].replace('-', '')
	id = list[name]
	print(id)
	# print(today)
	s3_client = boto3.client(
        		's3',
                aws_access_key_id=ACCESS_KEY_ID,
                aws_secret_access_key=ACCESS_SECRET_KEY
    		)
	response_01 = s3_client.upload_file(
    today+'_01.png', BUCKET_NAME, str(id)+'/'+today+'_01.png', ExtraArgs={'ACL':'public-read'},)
	print(response_01)

	response_02 = s3_client.upload_file(
	today + '_02.png', BUCKET_NAME, str(id)+'/'+ today + '_02.png', ExtraArgs={'ACL': 'public-read'}, )
	print(response_02)

	imgUrl_update(str(id)+'/'+today+'_01.png', str(id)+'/'+today+'_02.png', id, int(today))



handle_upload_img('이채영')
