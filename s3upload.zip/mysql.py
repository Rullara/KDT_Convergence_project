import pymysql
from datetime import datetime

# MySQL Connection 연결

def imgUrl_update(imgUrl1, imgUrl2, id, today):
    print("ddddd", id)

    conn = pymysql.connect(host='3.99.14.2',
                           user='root',
                           password='1234',
                           db='dmdm',
                           charset='utf8')
    curs = conn.cursor()


    # ==== select example ====
    sql = f"select * from student_student where id ={id}"
    curs.execute(sql)

    rows = curs.fetchall()
    print(rows[0])
    # [1][2][6]
    # [3]은 today
    print(rows[0][1])
    name = rows[0][1]
    cc = rows[0][4]

    # 데이타 Fetch
    # rows = curs.fetchall()
    # print(rows)
    #
    # name = ""
    # class_code = ""
    # imgUrl = ""

    # ==== insert example ====
    imgUrl1 = ' https://team7-dmdm.s3.ca-central-1.amazonaws.com/'+imgUrl1
    imgUrl2 = ' https://team7-dmdm.s3.ca-central-1.amazonaws.com/'+imgUrl2
    sql = """insert into student_studentdetail(name,class_code,update_date,imgUrl1,imgUrl2,student_id)
             values (%s, %s, %s, %s, %s, %s)"""
    curs.execute(sql, (name, cc, today, imgUrl1, imgUrl2, id))
    conn.commit()
    # commit 한번만 해도되는지

    # # ==== update OR delete example ====

    sql = f"""update student_student
             set imgUrl1 = '{imgUrl1}', imgUrl2 = '{imgUrl2}'
             where id = {id}"""
    curs.execute(sql)

    # sql = "delete from customer where id=%s"
    # curs.execute(sql, 6)

    conn.commit()

    # update  student_student set  imgUrl1 = 'dddd', imgUrl2 = 'ssss'  where  name = '성재윤';